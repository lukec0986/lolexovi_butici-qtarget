Locales["hu"] = {
	["valid_this_purchase"] = "Megerősíted a vásárlást?",
	["yes"] = "igen",
	["no"] = "nem",
	["not_enough_money"] = "Nincs elég pénzed",
	["press_menu"] = "Nyomd meg a [E] gombot a  Ruhabolt megnyitásához.",
	["clothes"] = "ruhabolt",
	["you_paid"] = "fizettél %s$-t",
	["save_in_dressing"] = "Menteni szeretnéd a ruhát az ingatlanodban?",
	["name_outfit"] = "Ruha neve",
	["saved_outfit"] = "Ruha mentésre került!",
}
